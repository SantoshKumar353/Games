# Unity-Speedometer
A simple speedometer made with Unity<br>
<br>
You can check out the tutorial for this code here:<br>
https://www.youtube.com/watch?v=CC8j_fU2GTQ<br>
<br>
▁▂▅▆▇ 📲 Social Media and Contacts 📲 ▇▆▅▂▁<br>
➡ WEBSITE - https://thedevelopers.tech<br>
📌YOUTUBE - https://www.youtube.com/channel/UCwO0k5dccZrTW6-GmJsiFrg<br>
📘FACEBOOK - https://www.facebook.com/VicTor-372230180173180<br>
📒INSTAGRAM - https://www.instagram.com/thedeveloper10/<br>
💎TWITTER - https://twitter.com/the_developer10<br>
✶LINKEDIN - https://www.linkedin.com/company/65346254
